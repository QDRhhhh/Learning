rm ./data_maker/*.in || true
rm ./data_maker/*.out || true
rm ./*.exe || true
rm ./src/*.o || true