#ifndef __MAX_SUB_MATRIX_SUM_N3__
#define __MAX_SUB_MATRIX_SUM_N3__

#include "stdlib.h"
#include "matrix_utils.h"
// #include "helper/CNewbieHelper.h"

int calMaxSubMatrixSum(Matrix * mat);

#endif