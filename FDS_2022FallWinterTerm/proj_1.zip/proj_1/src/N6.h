#ifndef __MAX_SUB_MATRIX_SUM_N6__
#define __MAX_SUB_MATRIX_SUM_N6__

#include "stdlib.h"
#include "matrix_utils.h"

int calMaxSubMatrixSum(Matrix * mat);

#endif